import React, { Component } from 'react';
import { Animated, ActivityIndicator, TextInput, View, TouchableOpacity, Text, StyleSheet, Dimensions, ScrollView, Image, ImageBackground } from 'react-native';
import { styles } from './styles';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
const width = Dimensions.get('window').width
const height = Dimensions.get('window').height
export class HomeScreen extends Component {

    static navigationOptions = {
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            text: '',
            user_name: 'dhaval.shah',
            phone_no: '',
            activeTab: 0,
            password: 'Dhaval@123',
            loading: false
        };
    }

    async componentDidMount() {

    }

    render() {
        return (
            <ImageBackground source={require('../../assets/images/backgroundImage.png')} style={{ flex: 1 }}>
                <View style={styles.header}>
                    <View style={{flex:1}}>
                        <TouchableOpacity style={styles.menuCircle} onPress={() => this.props.navigation.openDrawer()}>
                            {/* <MaterialIcons name="clear-all" size={40} color="#000" /> */}
                            <Image
                                style={{flex:1,height:undefined,width:undefined}}
                                source={require('../../assets/images/menu_green.png')}
                            />
                        </TouchableOpacity>
                    </View>
                    <Text style={styles.HeaderTitle}>Home</Text>
                </View>
                <View style={styles.mainContainer}>

                    <View style={styles.optionBox}>
                        <Image 
                            source={require('../../assets/images/beModel.png')}
                            style={styles.boxImageStyle}
                        />
                        <Text style={styles.boxText}>Be a Model</Text>
                    </View>
                    <View style={styles.optionBox}>
                        <Image 
                            source={require('../../assets/images/helpModel.png')}
                            style={styles.boxImageStyle}
                        />
                        <Text style={styles.boxText}>Help a Model</Text>
                    </View>

                </View>
            </ImageBackground>
        );
    }
}

export default HomeScreen