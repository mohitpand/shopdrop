import {StyleSheet,Dimensions} from 'react-native';
import { heightPercentageToDP, widthPercentageToDP } from "../../common/ResponsiveLayout";
const width = Dimensions.get('window').width
const height = Dimensions.get('window').height

export const styles = StyleSheet.create(
    {
        safeareaviewcontainer: {
            flex: 1,
          },
        MainContainer:{
            flex:1,
            backgroundColor:'yellow',
            resizeMode:'contain'
        },
        logoview:{
            width:widthPercentageToDP("100%"),
            height:heightPercentageToDP("25%"),  
            justifyContent:'center',
            alignItems:'center',
        },
        Imagelogo:{
            width:heightPercentageToDP("40%"),
            height:heightPercentageToDP("50%"),
            resizeMode:'contain',  
            padding:50,     
        },
      DetailBoxView:{
       flex:1,
      },
      txtview:{
        flex:1,
       
      },
      txtboxview:{
       flex:1,
       
      },
      txtbox:{
        borderWidth:1,
        borderRadius:35,
        width:"98%",
        height:50,
        borderColor:'green'
       },
      titletxt:{
          fontSize:heightPercentageToDP("3.1%"),
          fontWeight:'bold',
          alignSelf:'center'
      },
      detailtxt:{
          alignSelf:'center',
          alignContent:'center',
          fontSize:heightPercentageToDP("2.1%"),
          fontWeight:'200',
          marginTop:5,
          textAlign:'center'
      },
      frgtview:{
        marginLeft:90,
        marginRight:90,
        paddingBottom:30
      
      },
      btnview:{
        flex:0.2,
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'space-evenly',
 
      },
      btn:{
        backgroundColor:'#fff',
        borderRadius:30,
        marginLeft:20,
        marginRight:20
      },
      btntxt:{
        alignSelf:'center',
        fontSize:heightPercentageToDP("1.9%"),
        fontWeight:'500',
        padding:20
      },
      iconbtnview:{
        justifyContent:'center',
        alignItems:'center',
        width:widthPercentageToDP("44.0%"),
        height:heightPercentageToDP("8.0%"),
        borderWidth: 1,
        borderRadius: 30,
        backgroundColor:'white',
        borderColor: 'white',
        shadowColor: 'white',
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 2,
        shadowRadius: 2,
      },
      iconbtn:{
        width:widthPercentageToDP("8.1%"),
        height:heightPercentageToDP("4.1%"),
      },
      signintxt:{
        alignSelf:'center',
        alignContent:'center',
        fontSize:heightPercentageToDP("2.5%"),
        fontWeight:'400',
        textAlign:'center',
        color:'#02A0EC'
      },
      navigatetxtview:{
        flex:0.4,
        flexDirection:'row',
        justifyContent:'center'
      },
      signinblktxt:{
        alignSelf:'center',
        alignContent:'center',
        fontSize:heightPercentageToDP("2.0%"),
        fontWeight:'400',
        textAlign:'center',
        justifyContent:'center'
      },
      signinbluetxt:{
       
        fontSize:heightPercentageToDP("2.0%"),
        fontWeight:'400',
        textAlign:'center',
        color:'#02A0EC'
      },

    
    
    });