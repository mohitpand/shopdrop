import { StyleSheet, Dimensions } from 'react-native';
const width = Dimensions.get('window').width
const height = Dimensions.get('window').height
import { widthPercentageToDP, heightPercentageToDP } from '../../common/ResponsiveLayout';
import { color } from 'react-native-reanimated';
export const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
        paddingVertical: 20,
    },
    progress: {
        margin: 10,
        width: '85%'
    },
    progressbartitle: {
        flexDirection: 'row',
        marginHorizontal: 29,
        justifyContent: 'center',
        alignItems: 'center'
    },
    progressbarView: {
        width: '100%',
        justifyContent: 'center',
        alignItems: 'center'
    },
    imageStyle: {
        resizeMode: 'contain',
        height: undefined,
        width: undefined,
        flex: 1
    },
    imageview: {
        height: heightPercentageToDP('60%'),
        width: '100%',
        padding: 5
    },
    perTextStyle:{
        fontSize:heightPercentageToDP("2.1%"),
        fontWeight:'bold'
    },
    logoimageview:{
        height: heightPercentageToDP('15%'),
        width: '90%',
        marginHorizontal:15,
        justifyContent:'center',
        alignSelf:'center',
        padding:10,
        marginTop:heightPercentageToDP('10%')
    },
    logoimageStyle:{
        resizeMode: 'contain',
        height: undefined,
        width: undefined,
        flex: 1,
        alignItems:'center'
    },
    subtitletextstyle:{
        textAlign:'center',
        fontSize:heightPercentageToDP('2.1%'),
        fontWeight:'bold'
    }
})