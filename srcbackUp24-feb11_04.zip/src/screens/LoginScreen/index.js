import React, { Component } from 'react';
import { Animated, ActivityIndicator, TextInput, View, TouchableOpacity, Text, StyleSheet, Dimensions, ScrollView, Image, ImageBackground, SafeAreaView } from 'react-native';
import { styles } from './styles';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { FullButton } from '../../components/FullButton';

import { TextBox } from '../../components/TextBox';
const width = Dimensions.get('window').width
const height = Dimensions.get('window').height

export class LoginScreen extends Component {

    static navigationOptions = {
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            email: '',
            password: '',
            errormessage: '',
            emailerror: false
        };
    }
    validate = () => {

        var emt = this.state.email;
        console.log('Empty email' + JSON.stringify(emt));
        var emailregx = /^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/
        if (emt === "") {
            this.setState({ emailerror: true, errormessage: 'User not found' })
        }
        else {
            if (emailregx.test(emt)) {
                this.setState({ emailerror: false, confirmCodeMsg: 'The confirmation code was sent to your email, please enter it here:' });
                console.log("Valid Email");
            } else {
                this.setState({ emailerror: true, errormessage: 'Your email is not valid' })
            }
        }
    }

    /*  async validatePhonenumber(){
       var email = this.state.email
       let withoutspace = email.replace(/\s/g,'')
       var isnum = /^\d+$/.test(withoutspace);
       if(isnum){
         var is10Digit = /^\d{10}$/.test(withoutspace)
         if(is10Digit){
           //alert('correct,it is a 10 digits number')
           this.setState({ emailerror: false,inputType:'phone',confirmCodeMsg:'The confirmation code was sent to your phone number, please enter it here:'});
           await this.props.getVerificationCode(withoutspace,this.state.deviceId,'phone')
         }else{
           this.setState({ emailerror: true , codeSent: false });
         }
       }else{
         this.setState({ emailerror: true , codeSent: false });
       } 
     }*/

     navigationScreen=()=>{
        this.props.navigation.navigate('ForgotPasswordScreen')
     }
    render() {
        return (
            <SafeAreaView style={styles.safeareaviewcontainer}>
                <ImageBackground source={require('../../assets/images/whitebackground.jpg')} style={styles.MainContainer} >
                    <View style={styles.logoview} >
                        <Image source={require('../../assets/images/logo.png')} style={styles.Imagelogo}></Image>
                    </View>
                    <View style={styles.DetailBoxView} >
                        <View style={styles.txtboxview}>

                            <TextBox textInputStyle={[styles.txtbox,{borderColor:this.state.emailerror === true ? 'red' : '#dedede'}]}
                                placeholder="Email"
                                returnKeyType="next"
                                textContentType="username"
                                onChangeText={(value) => this.setState({ email: value })} />
                            {
                                this.state.emailerror === true ?
                                    <View style={{ height: 20, width: '100%', marginHorizontal: 25 }}>
                                        <Text style={{ color: 'red' }}>{this.state.errormessage}</Text>
                                    </View> : <View style={{ height: 20, width: '100%', marginHorizontal: 25 }}>
                                    </View>
                            }
                            <TextBox textInputStyle={[styles.txtbox]}
                                placeholder="password"
                                returnKeyType="go"
                                secureTextEntry={true}
                                textContentType="password"
                                onChangeText={(value) => this.setState({ password: value })} />
                            {
                               /*  this.state.emailerror === true ?
                                    <View style={{ height: 20, width: '100%', marginHorizontal: 25 }}>
                                        <Text style={{ color: 'red' }}>{this.state.errormessage}</Text>
                                    </View> : <View style={{ height: 20, width: '100%', marginHorizontal: 25 }}>
                                    </View> */
                            }
                            <TouchableOpacity onPress={() => this.navigationScreen()} style={styles.frgtview}>
                                <Text style={styles.signintxt}>Forgot user/Password?</Text>
                            </TouchableOpacity>
                            <FullButton
                                buttonText={'Create account'}
                                onPress={() => this.validate()}
                            />

                        </View>
                        <View style={styles.btnview} >
                            <TouchableOpacity style={styles.iconbtnview}
                                onPress={() => Alert.alert('back to sign in')} >
                                {/* <Image source ={require('/kandarp/React/dhavalTestFeedback/dev/ShopDrop/src/images/facebook.png')} style={styles.iconbtn} ></Image> */}
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.iconbtnview} onPress={() => Alert.alert('back to sign in')} >
                                {/* <Image source ={require('/kandarp/React/dhavalTestFeedback/dev/ShopDrop/src/images/google.png')} style={styles.iconbtn} ></Image> */}
                            </TouchableOpacity>
                        </View>
                        <View style={styles.navigatetxtview}>
                            <Text style={styles.signinblktxt} >Don't have an account? </Text>
                            <TouchableOpacity onPress={() => {this.props.navigation.navigate('SignUpScreen')}} style={styles.signinblktxt}>
                                <Text style={styles.signinbluetxt}>Sign Up</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </ImageBackground>
            </SafeAreaView>
        );
    }

}

export default LoginScreen