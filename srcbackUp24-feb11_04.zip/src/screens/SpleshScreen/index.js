import React, { Component } from 'react';
import { View, TouchableOpacity, Text, Dimensions, ScrollView, ImageBackground, Image } from 'react-native';
import { styles } from './styles';
import * as Progress from 'react-native-progress';


export class SpleshScreen extends Component {
    static navigationOptions = {
        header: null
    };

    constructor(props) {
        super(props);
        this.state = {
            progress: 0,
            indeterminate: true,
        };
    }
    componentDidMount() {
        this.animate();
    }
    onDone = () => {
        this.props.navigation.navigate('AuthNavigator')
     }
    animate() {
        let progress = 0;
        this.setState({ progress });
        setTimeout(() => {
            this.setState({ indeterminate: false });
            setInterval(() => {
                progress += Math.random() / 5;
                if (progress > 1) {
                    progress = 1;
                    this.props.navigation.navigate('IntroScreen')
                }
                this.setState({ progress });
            }, 500);
        }, 1500);
    }
    render() {
        return (
            <ImageBackground source={require('../../assets/images/background_splash.png')} style={{ flex: 1 }}>

                <View style={styles.logoimageview}>
                    <Image 
                    style={styles.logoimageStyle}
                    source={require('../../assets/images/logo.png')}
                    />
                </View>
                <Text style={styles.subtitletextstyle}>Bringing Together Lovers of Fashion</Text>
                <View style={styles.imageview}>
                    <Image
                        style={styles.imageStyle}
                        source={require('../../assets/images/helpmodel_homescreen.png')}
                    />
                </View>
                <View style={styles.progressbarView}>
                    <Progress.Bar
                        style={styles.progress}
                        progress={this.state.progress}
                        indeterminate={this.state.indeterminate}
                        color={['#06fbc7']}
                        width={500}
                    />
                    <View style={styles.progressbartitle}>
                        <View style={{ flex: 3 }}>
                            <Text>Loading......</Text>
                        </View>
                        <View style={{ flex: 1, alignItems: 'flex-end' }}>
                            <Text style={styles.perTextStyle}>{(this.state.progress * 100).toFixed(0)}%</Text>
                        </View>
                    </View>
                </View>

            </ImageBackground>
        )
    }
}

export default SpleshScreen;