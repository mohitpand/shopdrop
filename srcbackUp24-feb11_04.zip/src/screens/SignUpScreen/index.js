import React, { Component } from 'react';

import { View, Text, ImageBackground, Image, TouchableOpacity, SafeAreaView, Alert } from 'react-native';

import {TextBox} from '../../components/TextBox';

import {FullButton} from '../../components/FullButton'; 

import { styles } from './styles';

import CheckBox from 'react-native-check-box';


export class SignUpScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isChecked: true
        }
    }

    render() {
        return (
            <SafeAreaView style={styles.safeareaviewcontainer}>
                <ImageBackground source={require('../../assets/images/whitebackground.jpg')} style={styles.MainContainer} >
                    <View style={styles.logoview} >
                        <Image source={require('../../assets/images/logo.png')} style={styles.Imagelogo}></Image>
                    </View>
                    <View style={styles.DetailBoxView} >
                        <View style={styles.txtboxview}>
                          
                                <TextBox textInputStyle={styles.txtbox}
                                    placeholder="Full name"
                                    returnKeyType="next"
                                    textContentType="username"
                                />
                                
                                <TextBox textInputStyle={styles.txtbox}
                                    placeholder="Contact number"
                                    returnKeyType="go"
                                    secureTextEntry={true}
                                    textContentType="password"
                                />
                                
                                <TextBox textInputStyle={styles.txtbox}
                                    placeholder="Username"
                                    returnKeyType="go"
                                    secureTextEntry={true}
                                    textContentType="password"
                                />
                                
                                <TextBox textInputStyle={styles.txtbox}
                                    placeholder="Email"
                                    returnKeyType="go"
                                    secureTextEntry={true}
                                    textContentType="password"
                                />
                                
                                <TextBox textInputStyle={styles.txtbox}
                                    placeholder="Password"
                                    returnKeyType="go"
                                    secureTextEntry={true}
                                    textContentType="password"
                                />
                                
                            
                            <View style={styles.termstxtview}>
                                <View >
                                    <CheckBox
                                        style={styles.signinblktxt}
                                        checkBoxColor="#B2DCFA"
                                        checkedCheckBoxColor="#B1DCFA"
                                        onClick={() => {
                                            this.setState({
                                                isChecked: !this.state.isChecked
                                            })
                                        }}
                                        isChecked={this.state.isChecked}
                                        rightText={"agree to"}
                                    />
                                </View>
                                <Text style={styles.signinblktxt} >Agree to </Text>
                                <TouchableOpacity onPress={() => Alert.alert('back to sign in')} style={styles.signinblktxt}>
                                    <Text style={styles.signinbluetxt}>
                                        Terms & conditions.
                      </Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                        
                            <FullButton buttonText={'Create account'} >
                                
                            </FullButton>
                        
                        <View style={styles.navigatetxtview}>
                            <Text style={styles.signinblktxt} >Don't have an account? </Text>
                            <TouchableOpacity onPress={() => Alert.alert('back to sign in')} style={styles.signinblktxt}>
                                <Text style={styles.signinbluetxt}>
                                    Sign in
                      </Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </ImageBackground>
            </SafeAreaView>
        );
    }
}

export default SignUpScreen;