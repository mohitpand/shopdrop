import { StyleSheet, Dimensions } from 'react-native';
import { heightPercentageToDP, widthPercentageToDP } from "../../common/ResponsiveLayout";
const width = Dimensions.get('window').width
const height = Dimensions.get('window').height

export const styles = StyleSheet.create(
    {
        safeareaviewcontainer: {
            flex: 1,
        },
        MainContainer: {
            width: '100%',
            height: '100%'
        },
        logoview:{
            width:widthPercentageToDP("100%"),
            height:heightPercentageToDP("25%"),  
            justifyContent:'center',
            alignItems:'center',
        },
        Imagelogo:{
            width:heightPercentageToDP("40%"),
            height:heightPercentageToDP("50%"),
            resizeMode:'contain',  
            padding:50,     
        },
        DetailBoxView: {
            flex: 1,
        },
        txtview: {
            flex: 1,
            
        },
        txtboxview: {
            flex: 1,
            
        },
        txtbox: {
            borderWidth: 1,
            borderRadius: 30,
            
            marginLeft: 20,
            marginRight: 20,
            marginBottom:5
        },
        titletxt: {
            fontSize: heightPercentageToDP("3.1%"),
            fontWeight: 'bold',
            alignSelf: 'center'
        },
        detailtxt: {
            alignSelf: 'center',
            alignContent: 'center',
            fontSize: heightPercentageToDP("2.1%"),
            fontWeight: '200',
            marginTop: 5,
            textAlign: 'center'
        },
        frgtview: {
            marginLeft: 90,
            marginRight: 90,
            paddingBottom: 30

        },
        btnview: {
            flex: 0.2,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-evenly',

        },
        btn: {
            backgroundColor: '#B2DCFA',
            borderRadius: 30,
            marginLeft: 20,
            marginRight: 20
        },
        btntxt: {
            alignSelf: 'center',
            fontSize: heightPercentageToDP("1.9%"),
            fontWeight: '500',
            padding: 20
        },
        iconbtnview: {
            justifyContent: 'center',
            alignItems: 'center',
            width: widthPercentageToDP("44.0%"),
            height: heightPercentageToDP("8.0%"),
            borderWidth: 1,
            borderRadius: 30,
            borderColor: '#ECF0F1',
            shadowColor: '#ECF0F1',
            shadowOffset: { width: 0, height: 3 },
            shadowOpacity: 5,
            shadowRadius: 3,
        },
        iconbtn: {
            width: widthPercentageToDP("8.1%"),
            height: heightPercentageToDP("4.1%"),
        },
        signintxt: {
            alignSelf: 'center',
            alignContent: 'center',
            fontSize: heightPercentageToDP("2.5%"),
            fontWeight: '400',
            textAlign: 'center',
            color: '#02A0EC'
        },
        termstxtview: {
            marginBottom: 30,
            padding: 20,
            flexDirection: 'row',
            justifyContent: 'center'
        },
        navigatetxtview: {
            padding: 20,
            flexDirection: 'row',
            justifyContent: 'center'
        },
        signinblktxt: {
            alignSelf: 'center',
            alignContent: 'center',
            fontSize: heightPercentageToDP("2.0%"),
            fontWeight: '400',
            textAlign: 'center',
            justifyContent: 'center'
        },
        signinbluetxt: {

            fontSize: heightPercentageToDP("2.0%"),
            fontWeight: '400',

            textAlign: 'center',
            color: '#02A0EC'
        },



    });