import React, { Component } from 'react';

import { View, TextInput, Text, ImageBackground, Image, TouchableOpacity, Button, SafeAreaView, Alert } from 'react-native';

import { styles } from './styles';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { TextBox } from '../../components/TextBox';

import { FullButton } from '../../components/FullButton';

export class ForgotPasswordScreen extends Component {

  static navigationOptions = {
    header: null
  };
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      emailerror: false,
      errormessage: '',

    };
  }
  validate = () => {

    var emt = this.state.email;
    console.log('Empty email' + JSON.stringify(emt));
    var emailregx = /^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/
    if (emt === "") {
      this.setState({ emailerror: true, errormessage: 'Email not found' })
    }
    else {
      if (emailregx.test(emt)) {
        this.setState({ emailerror: false, confirmCodeMsg: 'The confirmation code was sent to your email, please enter it here:' });
        console.log("Valid Email");
      } else {
        this.setState({ emailerror: true, errormessage: 'Your email is not valid' })
      }
    }
  }
  render() {
    return (
      <SafeAreaView style={styles.safeareaviewcontainer}>
        <ImageBackground source={require('../../assets/images/whitebackground.jpg')} style={styles.MainContainer} >
          <View style={styles.headerview} >
            <TouchableOpacity style={styles.leftbtn} onPress={() => this.props.navigation.goBack(null)}>
              <Ionicons name="ios-arrow-back" size={35} color="#000" />
            </TouchableOpacity>
          </View>
          <View style={styles.DetailBoxView} >
            <View style={styles.txtview} >
              <Text style={styles.titletxt}> Forget Password </Text>
              <Text style={styles.detailtxt}> Please enter your email Address below{"\n"} to retrieve your password  </Text>
            </View>
            <View style={styles.txtboxview}>
              <TextBox textInputStyle={[styles.txtbox,{borderColor:this.state.emailerror === true ? 'red' : '#dedede'}]}
                placeholder="Email"
                returnKeyType="next"
                onChangeText={(value) => this.setState({ email: value })}
              >
              </TextBox>
            </View>
            {
              this.state.emailerror === true ?
                <View style={{ height: 20, width: '100%', marginHorizontal: 25 }}>
                  <Text style={{ color: 'red' }}>{this.state.errormessage}</Text>
                </View> : <View style={{ height: 20, width: '100%', marginHorizontal: 25 }}>
                </View>
            }
            <View style={styles.btnview}>
              <FullButton
                onPress={() => { this.validate() }}
                buttonText={'Send'} />


            </View>
            <View style={styles.navigatetxtview}>
              <TouchableOpacity onPress={() => this.props.navigation.goBack(null)}>
                <Text style={styles.signintxt}>
                  Back to sign in
                      </Text>
              </TouchableOpacity>
            </View>
          </View>


        </ImageBackground>
      </SafeAreaView>
    );
  }
}
export default ForgotPasswordScreen;