import {StyleSheet,Dimensions} from 'react-native';
import { heightPercentageToDP, widthPercentageToDP } from "../../common/ResponsiveLayout";
const width = Dimensions.get('window').width
const height = Dimensions.get('window').height

export const styles = StyleSheet.create(
    {
        safeareaviewcontainer: {
            flex: 1,
          },
        MainContainer:{
            width:'100%',
            height:'100%'
            
        },
        headerview:{
         
            flex:0.1,
            justifyContent:'center'
        },
        leftbtn:{
            alignSelf:'baseline',
            padding:5
        },
        Imagelogo:{
            width:widthPercentageToDP("4.0%"),
            height:heightPercentageToDP("3.0%"),
            justifyContent:'center',
            margin:5,
            marginLeft:25
               
        },
      DetailBoxView:{
       marginTop:10,
       flex:0.4,
       justifyContent:'space-around',
      },
      txtview:{
       flex:1,
       padding:10
      },
      txtboxview:{
       flex:1,
       justifyContent:'space-around',
       marginTop:10
      },
      txtbox:{
        borderRadius:35
       },
      titletxt:{
          fontSize:heightPercentageToDP("3.1%"),
          fontWeight:'bold',
          alignSelf:'center',
          paddingBottom:10
      },
      detailtxt:{
          alignSelf:'center',
          alignContent:'center',
          fontSize:heightPercentageToDP("2.1%"),
          fontWeight:'200',
          marginTop:1,
          textAlign:'center'
      },
      btnview:{
        flex:1,
        justifyContent:'space-around',
      },
      btn:{
        backgroundColor:'#06FBC7',
        borderRadius:30,
        padding:10,
        marginLeft:20,
        marginRight:20,
      },
      btntxt:{
        alignSelf:'center',
        fontSize:heightPercentageToDP("1.9%"),
        fontWeight:'500',
      },
      signintxt:{
        alignSelf:'center',
        alignContent:'center',
        fontSize:heightPercentageToDP("2.5%"),
        fontWeight:'400',
        marginTop:10,
        textAlign:'center',
        color:'#02A0EC'
      }

    
    
    });